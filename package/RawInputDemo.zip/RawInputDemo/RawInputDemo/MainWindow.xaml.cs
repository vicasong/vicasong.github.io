﻿using RawInput;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Forms;

namespace RawInputDemo
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        private static RawInputManager rawinput;
        public MainWindow()
        {
            InitializeComponent();
        }

        void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            System.Windows.MessageBox.Show(e.ToString());
        }

        void rawinput_OnHotKeyPressed(object sender, RawHotKeyEventArg e)
        {
            hot.Text = "HotKey Actived!";
        }

        void rawinput_OnKeyPressed(object sender, RawKeyEventArg e)
        {
            sourcePath.Text = e.KeyPressEvent.DeviceName;
            keys.Text = e.KeyPressEvent.PressKeys;
            keyState.Text = e.KeyPressEvent.KeyPressState;
            hot.Text = "";
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            rawinput.OnHotKeyPressed -= rawinput_OnHotKeyPressed;
        }

        private void Window_Initialized(object sender, EventArgs e)
        {
            AppDomain.CurrentDomain.UnhandledException += CurrentDomain_UnhandledException;
        }
        //[System.Runtime.InteropServices.DllImport("user32.dll")]
        //public static extern IntPtr GetForegroundWindow();
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //IntPtr myPtr = GetForegroundWindow();
            IntPtr handle=new WindowInteropHelper(this).Handle;
            KeyMap[] hotkey = { KeyMap.LWin, KeyMap.LMenu, KeyMap.C };
            rawinput = new RawInputManager(handle, false);
            rawinput.HotKeys = hotkey;
            rawinput.AddMessageFilter();
            rawinput.OnKeyPressed += rawinput_OnKeyPressed;
            rawinput.OnHotKeyPressed += rawinput_OnHotKeyPressed;
        }
    }
}
